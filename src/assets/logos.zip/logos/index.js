import LogoBig from "./25422.png";
import LogoBlack from "./black.png";
import RedLogo from "./red.png";
import BlackRed from "./black-red.png";
import LogoUser from "./togetherlogo.png";
import LogoDash from "./togetherdash.png";
import WhiteLogo from "./wi.png";

export { LogoBig, LogoBlack, RedLogo, BlackRed, LogoUser, LogoDash, WhiteLogo };
